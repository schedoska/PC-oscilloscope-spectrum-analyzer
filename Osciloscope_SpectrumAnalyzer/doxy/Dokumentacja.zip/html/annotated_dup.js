var annotated_dup =
[
    [ "Cursor", "class_cursor.html", "class_cursor" ],
    [ "CursorData", "struct_cursor_data.html", "struct_cursor_data" ],
    [ "DataCommuniaction", "class_data_communiaction.html", "class_data_communiaction" ],
    [ "fftw_iodim64_do_not_use_me", "structfftw__iodim64__do__not__use__me.html", "structfftw__iodim64__do__not__use__me" ],
    [ "fftw_iodim_do_not_use_me", "structfftw__iodim__do__not__use__me.html", "structfftw__iodim__do__not__use__me" ],
    [ "FrequencySample", "struct_frequency_sample.html", "struct_frequency_sample" ],
    [ "LanguageSettingsDialog", "class_language_settings_dialog.html", "class_language_settings_dialog" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "OscilloscopeChart", "class_oscilloscope_chart.html", "class_oscilloscope_chart" ],
    [ "PortSettingsDialog", "class_port_settings_dialog.html", "class_port_settings_dialog" ],
    [ "Sample", "struct_sample.html", "struct_sample" ],
    [ "SerialPortSettings", "struct_serial_port_settings.html", "struct_serial_port_settings" ],
    [ "SignalGlobalInformation", "class_signal_global_information.html", "class_signal_global_information" ],
    [ "SpectrumChart", "class_spectrum_chart.html", "class_spectrum_chart" ]
];