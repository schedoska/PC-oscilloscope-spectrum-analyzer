var searchData=
[
  ['frequenciesdatalist_0',['frequenciesDataList',['../class_signal_global_information.html#a12568ce31bcf98b5d398677b73616698',1,'SignalGlobalInformation']]],
  ['frequenciesdataranking_1',['frequenciesDataRanking',['../class_signal_global_information.html#a7f037faba598fbda61bec1682cd844c0',1,'SignalGlobalInformation']]],
  ['frequencyrange_2',['frequencyRange',['../class_spectrum_chart.html#a751f535d1899a6623ededb1378484ba2',1,'SpectrumChart']]],
  ['frequencysample_3',['FrequencySample',['../struct_frequency_sample.html#a4a8466aaf14058754602dbd27e362efc',1,'FrequencySample']]]
];
