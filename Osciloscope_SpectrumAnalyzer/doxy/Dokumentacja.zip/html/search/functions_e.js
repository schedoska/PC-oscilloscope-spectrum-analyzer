var searchData=
[
  ['updatechart_0',['updateChart',['../class_oscilloscope_chart.html#a1f869e3894a19b41d6d64924d8b63407',1,'OscilloscopeChart::updateChart()'],['../class_spectrum_chart.html#a8debde08b9d81e27b9268298b6a49ef7',1,'SpectrumChart::updateChart()']]],
  ['updatecursordata_1',['updateCursorData',['../class_cursor.html#adf75402ce1b9a207a4e34e0b4abe08c5',1,'Cursor']]],
  ['updatecursorinfo_2',['updateCursorInfo',['../class_main_window.html#acd5d6c2737f325e7148fe8745254a436',1,'MainWindow']]],
  ['updatecursorinfospectrum_3',['updateCursorInfoSpectrum',['../class_main_window.html#a0d42a86ec5b6542b80dace556caebd5c',1,'MainWindow']]],
  ['updatecursorsdata_4',['updateCursorsData',['../class_oscilloscope_chart.html#af99d700825b21e169733c7f79a78d31a',1,'OscilloscopeChart::updateCursorsData()'],['../class_spectrum_chart.html#a4d5535da1bc8bdc7c5f16387b86048cb',1,'SpectrumChart::updateCursorsData()']]],
  ['updatedata_5',['updateData',['../class_main_window.html#a3f356223323116aac25891aefa0b8fdc',1,'MainWindow']]],
  ['updatelanguagesettings_6',['updateLanguageSettings',['../class_main_window.html#a48438ff5bdf8f8565299c898a67f3b41',1,'MainWindow']]],
  ['updateportsettings_7',['updatePortSettings',['../class_main_window.html#a58f114f7329a581500b95a262c57b398',1,'MainWindow']]]
];
