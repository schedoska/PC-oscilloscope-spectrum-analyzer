var searchData=
[
  ['fftw_5fiodim64_5fdo_5fnot_5fuse_5fme_0',['fftw_iodim64_do_not_use_me',['../structfftw__iodim64__do__not__use__me.html',1,'']]],
  ['fftw_5fiodim_5fdo_5fnot_5fuse_5fme_1',['fftw_iodim_do_not_use_me',['../structfftw__iodim__do__not__use__me.html',1,'']]],
  ['frequencysample_2',['FrequencySample',['../struct_frequency_sample.html',1,'']]]
];
