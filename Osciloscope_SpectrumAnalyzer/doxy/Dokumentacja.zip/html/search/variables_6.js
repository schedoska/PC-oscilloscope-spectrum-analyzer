var searchData=
[
  ['parity_0',['parity',['../struct_serial_port_settings.html#aa344eea2be35765bc74db9eacd38422f',1,'SerialPortSettings']]]
];
