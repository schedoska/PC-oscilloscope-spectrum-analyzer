var searchData=
[
  ['languagesettingsdialog_0',['LanguageSettingsDialog',['../class_language_settings_dialog.html',1,'']]]
];
