var searchData=
[
  ['value_0',['value',['../struct_cursor_data.html#a4ca2154e74c7185fa34ede2fa698b732',1,'CursorData::value()'],['../struct_sample.html#a1bacd8a34759c262688dfed674a4a78d',1,'Sample::value()'],['../struct_frequency_sample.html#a7c5aea9076573097fa35ca87326ba8e2',1,'FrequencySample::value()']]]
];
