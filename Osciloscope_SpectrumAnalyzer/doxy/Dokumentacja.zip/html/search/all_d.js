var searchData=
[
  ['time_0',['time',['../struct_cursor_data.html#ad249746418e26c449e2f86c66be6a4d9',1,'CursorData::time()'],['../struct_sample.html#a22b07d3b11382362c32e3a0286935db5',1,'Sample::time()']]],
  ['timebase_1',['timeBase',['../class_data_communiaction.html#ab3fa43389cf73e74164604ed72a11d65',1,'DataCommuniaction::timeBase()'],['../class_oscilloscope_chart.html#a71732d3739fdf3875fe70243f22c8fb2',1,'OscilloscopeChart::timeBase()']]],
  ['triggerslope_2',['TriggerSlope',['../oscilloscopechart_8h.html#a553eb766f03a9a6fd7d7740d89b784e1',1,'oscilloscopechart.h']]]
];
