var searchData=
[
  ['serialportinfo_0',['serialPortInfo',['../struct_serial_port_settings.html#aa31dba74ede187d254d3575bffaa9988',1,'SerialPortSettings']]],
  ['stopbits_1',['stopBits',['../struct_serial_port_settings.html#a5bd7e2ea31d621890fbb890bd2eb2796',1,'SerialPortSettings']]]
];
