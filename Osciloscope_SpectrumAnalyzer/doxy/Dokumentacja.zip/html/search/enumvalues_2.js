var searchData=
[
  ['none_0',['NONE',['../sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aab50339a10e1de285ac99d4c3990b8693',1,'sample.h']]]
];
