var searchData=
[
  ['baudrate_0',['baudRate',['../struct_serial_port_settings.html#a34d62dbaec748842cf5c793eedf97c3b',1,'SerialPortSettings']]]
];
