var searchData=
[
  ['slope_0',['Slope',['../sample_8h.html#a960d939f410021976dc835867de7fe0f',1,'sample.h']]]
];
