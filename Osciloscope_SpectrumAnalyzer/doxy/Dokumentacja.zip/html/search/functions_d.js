var searchData=
[
  ['timebase_0',['timeBase',['../class_data_communiaction.html#ab3fa43389cf73e74164604ed72a11d65',1,'DataCommuniaction::timeBase()'],['../class_oscilloscope_chart.html#a71732d3739fdf3875fe70243f22c8fb2',1,'OscilloscopeChart::timeBase()']]]
];
