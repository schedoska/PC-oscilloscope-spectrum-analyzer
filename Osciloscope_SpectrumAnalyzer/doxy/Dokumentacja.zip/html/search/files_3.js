var searchData=
[
  ['languagesettingsdialog_2ecpp_0',['languagesettingsdialog.cpp',['../languagesettingsdialog_8cpp.html',1,'']]],
  ['languagesettingsdialog_2eh_1',['languagesettingsdialog.h',['../languagesettingsdialog_8h.html',1,'']]]
];
