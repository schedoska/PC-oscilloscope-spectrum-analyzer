var searchData=
[
  ['fftw_5fread_5fchar_5ffunc_5fdo_5fnot_5fuse_5fme_0',['fftw_read_char_func_do_not_use_me',['../fftw3_8h.html#ac030197889a8c654b81dfc7cf5b82f67',1,'fftw3.h']]],
  ['fftw_5fwrite_5fchar_5ffunc_5fdo_5fnot_5fuse_5fme_1',['fftw_write_char_func_do_not_use_me',['../fftw3_8h.html#a19a4b195db13f4b211123e6b38f4916e',1,'fftw3.h']]]
];
