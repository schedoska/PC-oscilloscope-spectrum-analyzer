var searchData=
[
  ['ch_5f1_0',['CH_1',['../sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aa4df855c684eddf121d5d2dbb12bd5300',1,'sample.h']]],
  ['ch_5f1_5fand_5fch_5f2_1',['CH_1_AND_CH_2',['../sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aad1bc344bb0ff89a684a0a26144ebf5d2',1,'sample.h']]],
  ['ch_5f2_2',['CH_2',['../sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aae6fbcd7d63df3beba6285986cda83fcc',1,'sample.h']]]
];
