var searchData=
[
  ['time_0',['time',['../struct_cursor_data.html#ad249746418e26c449e2f86c66be6a4d9',1,'CursorData::time()'],['../struct_sample.html#a22b07d3b11382362c32e3a0286935db5',1,'Sample::time()']]]
];
