var searchData=
[
  ['calculatebasicinfo_0',['calculateBasicInfo',['../class_signal_global_information.html#ad094e8992569530515f8e75d0711407f',1,'SignalGlobalInformation']]],
  ['calculatefft_1',['calculateFFT',['../class_signal_global_information.html#a1de4b34189a421ea58f3746f8612377e',1,'SignalGlobalInformation']]],
  ['changeactive_5fch1_2',['changeActive_Ch1',['../class_main_window.html#a37c2edda0104e59127e56e5c971c085b',1,'MainWindow']]],
  ['changeactive_5fch2_3',['changeActive_Ch2',['../class_main_window.html#ab8afb5624e3a118bbb60d00388541002',1,'MainWindow']]],
  ['closeevent_4',['closeEvent',['../class_port_settings_dialog.html#a5f388c08d8e85523fc42b6bdb1124d3b',1,'PortSettingsDialog']]],
  ['cursor_5',['Cursor',['../class_cursor.html#a1164d416d5b348697fa4aed9e80f7ee5',1,'Cursor']]],
  ['cursordata_6',['cursorData',['../class_cursor.html#aa2ae38abb7ca2741443a4f3fc0ce61b1',1,'Cursor']]],
  ['cursordataupdated_7',['cursorDataUpdated',['../class_cursor.html#a67ca40ba0d64dd36e0446c86b83efc3e',1,'Cursor']]],
  ['cursorsdataupdated_8',['cursorsDataUpdated',['../class_oscilloscope_chart.html#a19449587e9fd007229a8ff104f70692d',1,'OscilloscopeChart::cursorsDataUpdated()'],['../class_spectrum_chart.html#abb9b7a936d5d67e1ddb1d03e11767481',1,'SpectrumChart::cursorsDataUpdated()']]]
];
