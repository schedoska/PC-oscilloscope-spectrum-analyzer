var searchData=
[
  ['newdataframeready_0',['newDataFrameReady',['../class_data_communiaction.html#aad3475bfb0732cf890ff9d1c78283b21',1,'DataCommuniaction']]]
];
