var searchData=
[
  ['languagechanged_0',['languageChanged',['../class_language_settings_dialog.html#a3fb78c6b143e7c439fad4e69828d7b15',1,'LanguageSettingsDialog']]],
  ['languagesettingsdialog_1',['LanguageSettingsDialog',['../class_language_settings_dialog.html#ac5963c7e975fb6205c4e2c96b45bbd2b',1,'LanguageSettingsDialog']]],
  ['languagesettingsupdated_2',['languageSettingsUpdated',['../class_language_settings_dialog.html#a3faca6fadcfdb62c76ad92086035bfd2',1,'LanguageSettingsDialog']]]
];
