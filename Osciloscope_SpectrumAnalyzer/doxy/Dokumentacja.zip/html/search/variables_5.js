var searchData=
[
  ['observedchannel_0',['observedChannel',['../struct_cursor_data.html#ab91bc4a5d03c5608cc50cc0e631c533b',1,'CursorData']]],
  ['os_1',['os',['../structfftw__iodim__do__not__use__me.html#acff6a6b2225f610d3bee5380e801abb4',1,'fftw_iodim_do_not_use_me::os()'],['../structfftw__iodim64__do__not__use__me.html#a44118d774124bdaa670f640537b151cf',1,'fftw_iodim64_do_not_use_me::os()']]]
];
