var searchData=
[
  ['datacommuniaction_0',['DataCommuniaction',['../class_data_communiaction.html#a73f838394082615ffd2aee6467d514d8',1,'DataCommuniaction']]],
  ['dataready_1',['dataReady',['../class_data_communiaction.html#a86605b1cb162b6a9ee4ed9ddaa5abac2',1,'DataCommuniaction']]]
];
