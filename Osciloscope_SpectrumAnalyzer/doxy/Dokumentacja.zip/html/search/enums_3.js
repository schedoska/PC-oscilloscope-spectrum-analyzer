var searchData=
[
  ['triggerslope_0',['TriggerSlope',['../oscilloscopechart_8h.html#a553eb766f03a9a6fd7d7740d89b784e1',1,'oscilloscopechart.h']]]
];
