var searchData=
[
  ['observedchannels_0',['observedChannels',['../class_spectrum_chart.html#a4b21bb88c86226c35e7028d215d25e5f',1,'SpectrumChart']]],
  ['oscilloscopechart_1',['OscilloscopeChart',['../class_oscilloscope_chart.html#a3fad5c8a831312d2b8c5058326973c16',1,'OscilloscopeChart']]]
];
