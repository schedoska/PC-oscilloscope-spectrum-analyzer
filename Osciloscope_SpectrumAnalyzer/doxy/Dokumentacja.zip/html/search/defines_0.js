var searchData=
[
  ['color_5frgb_5fchannel_5f1_0',['COLOR_RGB_CHANNEL_1',['../oscilloscopechart_8h.html#a6eb378cb80819b8dd09dcaaa0bb04883',1,'oscilloscopechart.h']]],
  ['color_5frgb_5fchannel_5f1_5fstring_1',['COLOR_RGB_CHANNEL_1_STRING',['../oscilloscopechart_8h.html#a658be01175fa40dd6de72f4b59144c5b',1,'oscilloscopechart.h']]],
  ['color_5frgb_5fchannel_5f2_2',['COLOR_RGB_CHANNEL_2',['../oscilloscopechart_8h.html#a615ffcb7776e7266d2b211af5e8f8e73',1,'oscilloscopechart.h']]],
  ['color_5frgb_5fchannel_5f2_5fstring_3',['COLOR_RGB_CHANNEL_2_STRING',['../oscilloscopechart_8h.html#aa2e2bb36129b8cff4146528a85985830',1,'oscilloscopechart.h']]],
  ['color_5frgb_5fdisabled_5fstring_4',['COLOR_RGB_DISABLED_STRING',['../mainwindow_8cpp.html#a420fbea9eea845e3db8f91ba2c7d88c9',1,'mainwindow.cpp']]]
];
