var searchData=
[
  ['avgvalue_0',['avgValue',['../class_signal_global_information.html#ae16c08a5456e48bace543c227c68478c',1,'SignalGlobalInformation']]]
];
