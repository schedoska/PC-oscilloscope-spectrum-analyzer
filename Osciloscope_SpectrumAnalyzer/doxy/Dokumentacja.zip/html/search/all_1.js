var searchData=
[
  ['baudrate_0',['baudRate',['../struct_serial_port_settings.html#a34d62dbaec748842cf5c793eedf97c3b',1,'SerialPortSettings']]],
  ['boundingrect_1',['boundingRect',['../class_cursor.html#a700d86aa01f9d20fb6f89a6492d184d4',1,'Cursor']]]
];
