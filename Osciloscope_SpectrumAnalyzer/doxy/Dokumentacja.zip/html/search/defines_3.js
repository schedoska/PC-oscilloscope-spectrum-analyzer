var searchData=
[
  ['spectrum_5fcolor_5frgb_5fchannel_5f1_0',['SPECTRUM_COLOR_RGB_CHANNEL_1',['../spectrumchart_8h.html#a26175337494fe965f5b8a418ca649723',1,'spectrumchart.h']]],
  ['spectrum_5fcolor_5frgb_5fchannel_5f1_5fstring_1',['SPECTRUM_COLOR_RGB_CHANNEL_1_STRING',['../spectrumchart_8h.html#a842dcc1293011d9713ea5b5e4f6b33a3',1,'spectrumchart.h']]],
  ['spectrum_5fcolor_5frgb_5fchannel_5f2_2',['SPECTRUM_COLOR_RGB_CHANNEL_2',['../spectrumchart_8h.html#abc477cdd608c877c4f9bbbd9d6f60264',1,'spectrumchart.h']]],
  ['spectrum_5fcolor_5frgb_5fchannel_5f2_5fstring_3',['SPECTRUM_COLOR_RGB_CHANNEL_2_STRING',['../spectrumchart_8h.html#af0a41aebae95630606162f7ce5ac51ae',1,'spectrumchart.h']]],
  ['stylesheet_5fdisabled_5flabel_5fstring_4',['STYLESHEET_DISABLED_LABEL_STRING',['../mainwindow_8cpp.html#abd7340e95d00c126bc7542e1b0998a83',1,'mainwindow.cpp']]],
  ['stylesheet_5fenabled_5flabel_5fstring_5',['STYLESHEET_ENABLED_LABEL_STRING',['../mainwindow_8cpp.html#aa7f79a084df754ada00f92dec5bb3710',1,'mainwindow.cpp']]]
];
