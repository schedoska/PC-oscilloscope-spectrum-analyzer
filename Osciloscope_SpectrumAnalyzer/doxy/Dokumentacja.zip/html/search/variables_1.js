var searchData=
[
  ['databits_0',['dataBits',['../struct_serial_port_settings.html#a746cf01d1124ca1e066456031fa9bc6d',1,'SerialPortSettings']]]
];
