var searchData=
[
  ['fftw_5fr2r_5fkind_5fdo_5fnot_5fuse_5fme_0',['fftw_r2r_kind_do_not_use_me',['../fftw3_8h.html#a5671d435423fef322bc1339a4ae5e8f0',1,'fftw3.h']]]
];
