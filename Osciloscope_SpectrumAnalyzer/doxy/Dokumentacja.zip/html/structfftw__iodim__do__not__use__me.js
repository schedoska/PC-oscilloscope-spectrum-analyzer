var structfftw__iodim__do__not__use__me =
[
    [ "is", "structfftw__iodim__do__not__use__me.html#a7571fd050be3b9c9486d41086b657099", null ],
    [ "n", "structfftw__iodim__do__not__use__me.html#aa9ceb61afc1731380bdb48305aa40ce0", null ],
    [ "os", "structfftw__iodim__do__not__use__me.html#acff6a6b2225f610d3bee5380e801abb4", null ]
];