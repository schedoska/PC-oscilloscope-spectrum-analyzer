var class_spectrum_chart =
[
    [ "SpectrumChart", "class_spectrum_chart.html#a37461877845840803bb2200307394634", null ],
    [ "cursorsDataUpdated", "class_spectrum_chart.html#abb9b7a936d5d67e1ddb1d03e11767481", null ],
    [ "frequencyRange", "class_spectrum_chart.html#a751f535d1899a6623ededb1378484ba2", null ],
    [ "observedChannels", "class_spectrum_chart.html#a4b21bb88c86226c35e7028d215d25e5f", null ],
    [ "setEnableCursor1", "class_spectrum_chart.html#adc827d55636a31ed70c6a20223f3b8d3", null ],
    [ "setEnableCursor2", "class_spectrum_chart.html#a4237df811cd59c0723cb14c4f485134a", null ],
    [ "setFrequencyRange", "class_spectrum_chart.html#a68775ea717e591812caf11356ddc970c", null ],
    [ "setObservedChannels", "class_spectrum_chart.html#a1fadc8d4c8af5cb5118a0537726ab0ec", null ],
    [ "updateChart", "class_spectrum_chart.html#a8debde08b9d81e27b9268298b6a49ef7", null ],
    [ "updateCursorsData", "class_spectrum_chart.html#a4d5535da1bc8bdc7c5f16387b86048cb", null ]
];