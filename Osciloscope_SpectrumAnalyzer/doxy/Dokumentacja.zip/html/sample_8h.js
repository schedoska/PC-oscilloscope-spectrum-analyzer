var sample_8h =
[
    [ "Sample", "struct_sample.html", "struct_sample" ],
    [ "FrequencySample", "struct_frequency_sample.html", "struct_frequency_sample" ],
    [ "Channel", "sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455a", [
      [ "NONE", "sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aab50339a10e1de285ac99d4c3990b8693", null ],
      [ "CH_1", "sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aa4df855c684eddf121d5d2dbb12bd5300", null ],
      [ "CH_2", "sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aae6fbcd7d63df3beba6285986cda83fcc", null ],
      [ "CH_1_AND_CH_2", "sample_8h.html#a1ce9b523fd4f3b5bbcadcd796183455aad1bc344bb0ff89a684a0a26144ebf5d2", null ]
    ] ],
    [ "Slope", "sample_8h.html#a960d939f410021976dc835867de7fe0f", [
      [ "RISING", "sample_8h.html#a960d939f410021976dc835867de7fe0fab3762d500f2ada6030da058853c195d6", null ],
      [ "FALLING", "sample_8h.html#a960d939f410021976dc835867de7fe0fa4f9d4539ac1e11a251e2afe022eba4e6", null ]
    ] ]
];