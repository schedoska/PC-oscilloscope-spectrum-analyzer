var struct_cursor_data =
[
    [ "observedChannel", "struct_cursor_data.html#ab91bc4a5d03c5608cc50cc0e631c533b", null ],
    [ "time", "struct_cursor_data.html#ad249746418e26c449e2f86c66be6a4d9", null ],
    [ "value", "struct_cursor_data.html#a4ca2154e74c7185fa34ede2fa698b732", null ]
];