var serialportsettings_8h =
[
    [ "SerialPortSettings", "struct_serial_port_settings.html", "struct_serial_port_settings" ]
];