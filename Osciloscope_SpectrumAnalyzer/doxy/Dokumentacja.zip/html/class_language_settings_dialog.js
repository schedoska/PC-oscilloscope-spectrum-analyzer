var class_language_settings_dialog =
[
    [ "LanguageSettingsDialog", "class_language_settings_dialog.html#ac5963c7e975fb6205c4e2c96b45bbd2b", null ],
    [ "languageChanged", "class_language_settings_dialog.html#a3fb78c6b143e7c439fad4e69828d7b15", null ],
    [ "languageSettingsUpdated", "class_language_settings_dialog.html#a3faca6fadcfdb62c76ad92086035bfd2", null ]
];