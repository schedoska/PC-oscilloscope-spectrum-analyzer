var hierarchy =
[
    [ "CursorData", "struct_cursor_data.html", null ],
    [ "fftw_iodim64_do_not_use_me", "structfftw__iodim64__do__not__use__me.html", null ],
    [ "fftw_iodim_do_not_use_me", "structfftw__iodim__do__not__use__me.html", null ],
    [ "FrequencySample", "struct_frequency_sample.html", null ],
    [ "QDialog", null, [
      [ "LanguageSettingsDialog", "class_language_settings_dialog.html", null ],
      [ "PortSettingsDialog", "class_port_settings_dialog.html", null ]
    ] ],
    [ "QGraphicsObject", null, [
      [ "Cursor", "class_cursor.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "DataCommuniaction", "class_data_communiaction.html", null ],
      [ "OscilloscopeChart", "class_oscilloscope_chart.html", null ],
      [ "SpectrumChart", "class_spectrum_chart.html", null ]
    ] ],
    [ "Sample", "struct_sample.html", null ],
    [ "SerialPortSettings", "struct_serial_port_settings.html", null ],
    [ "SignalGlobalInformation", "class_signal_global_information.html", null ]
];