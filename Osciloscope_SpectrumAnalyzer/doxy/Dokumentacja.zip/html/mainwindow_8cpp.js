var mainwindow_8cpp =
[
    [ "COLOR_RGB_DISABLED_STRING", "mainwindow_8cpp.html#a420fbea9eea845e3db8f91ba2c7d88c9", null ],
    [ "STYLESHEET_DISABLED_LABEL_STRING", "mainwindow_8cpp.html#abd7340e95d00c126bc7542e1b0998a83", null ],
    [ "STYLESHEET_ENABLED_LABEL_STRING", "mainwindow_8cpp.html#aa7f79a084df754ada00f92dec5bb3710", null ]
];