var struct_sample =
[
    [ "Sample", "struct_sample.html#aac29d655d2744895c1eadc5a573d16ef", null ],
    [ "Sample", "struct_sample.html#adafd0cd16a3d13c3af376b468cc1917b", null ],
    [ "time", "struct_sample.html#a22b07d3b11382362c32e3a0286935db5", null ],
    [ "value", "struct_sample.html#a1bacd8a34759c262688dfed674a4a78d", null ]
];