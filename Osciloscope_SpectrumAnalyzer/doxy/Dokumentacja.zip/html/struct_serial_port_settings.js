var struct_serial_port_settings =
[
    [ "baudRate", "struct_serial_port_settings.html#a34d62dbaec748842cf5c793eedf97c3b", null ],
    [ "dataBits", "struct_serial_port_settings.html#a746cf01d1124ca1e066456031fa9bc6d", null ],
    [ "parity", "struct_serial_port_settings.html#aa344eea2be35765bc74db9eacd38422f", null ],
    [ "serialPortInfo", "struct_serial_port_settings.html#aa31dba74ede187d254d3575bffaa9988", null ],
    [ "stopBits", "struct_serial_port_settings.html#a5bd7e2ea31d621890fbb890bd2eb2796", null ]
];