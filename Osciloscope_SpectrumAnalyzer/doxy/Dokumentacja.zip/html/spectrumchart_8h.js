var spectrumchart_8h =
[
    [ "SpectrumChart", "class_spectrum_chart.html", "class_spectrum_chart" ],
    [ "SPECTRUM_COLOR_RGB_CHANNEL_1", "spectrumchart_8h.html#a26175337494fe965f5b8a418ca649723", null ],
    [ "SPECTRUM_COLOR_RGB_CHANNEL_1_STRING", "spectrumchart_8h.html#a842dcc1293011d9713ea5b5e4f6b33a3", null ],
    [ "SPECTRUM_COLOR_RGB_CHANNEL_2", "spectrumchart_8h.html#abc477cdd608c877c4f9bbbd9d6f60264", null ],
    [ "SPECTRUM_COLOR_RGB_CHANNEL_2_STRING", "spectrumchart_8h.html#af0a41aebae95630606162f7ce5ac51ae", null ]
];