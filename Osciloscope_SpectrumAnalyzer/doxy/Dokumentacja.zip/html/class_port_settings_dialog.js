var class_port_settings_dialog =
[
    [ "PortSettingsDialog", "class_port_settings_dialog.html#a6da183f977226abd03645c8ba3692bb1", null ],
    [ "closeEvent", "class_port_settings_dialog.html#a5f388c08d8e85523fc42b6bdb1124d3b", null ],
    [ "portSettingsUpdated", "class_port_settings_dialog.html#a5799063d6928f429510b125a8dc90bcb", null ],
    [ "setDataBits", "class_port_settings_dialog.html#a91f5d382e145888920f9b2ecf42df6f4", null ],
    [ "setDefaultValues", "class_port_settings_dialog.html#a5ef937afee6540a60d27c736aaf4408d", null ],
    [ "setParity", "class_port_settings_dialog.html#ad8819172a823a9648b45acb982c9ac51", null ],
    [ "setPort", "class_port_settings_dialog.html#a2ac8fccff374046c9a4123c5ad67cc2a", null ],
    [ "setSpeed", "class_port_settings_dialog.html#a732bff7faa84a9fa5caa830aeb299797", null ],
    [ "setStopBits", "class_port_settings_dialog.html#a26437094639e990d439b3d7c56291a25", null ]
];