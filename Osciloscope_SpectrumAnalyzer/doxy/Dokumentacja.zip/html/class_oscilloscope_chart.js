var class_oscilloscope_chart =
[
    [ "OscilloscopeChart", "class_oscilloscope_chart.html#a3fad5c8a831312d2b8c5058326973c16", null ],
    [ "cursorsDataUpdated", "class_oscilloscope_chart.html#a19449587e9fd007229a8ff104f70692d", null ],
    [ "setObservedChannels", "class_oscilloscope_chart.html#af920793bb293fd967c76f1c5ab390a8a", null ],
    [ "setObservingChannelCursor_1", "class_oscilloscope_chart.html#a7c4761766895f0f44e50b38239779218", null ],
    [ "setObservingChannelCursor_2", "class_oscilloscope_chart.html#a49ae190a554da9c4ba42fa7c0e71b758", null ],
    [ "setTimeBase", "class_oscilloscope_chart.html#adf610d4e7cf90b9a0ae5b4142faf1d31", null ],
    [ "setVerticalDivCh_1", "class_oscilloscope_chart.html#afa0c453e5e1638df861719c4dda7be05", null ],
    [ "setVerticalDivCh_2", "class_oscilloscope_chart.html#a00764dc935977c75a71e6d75f1682a46", null ],
    [ "setVerticalOffsetCh_1", "class_oscilloscope_chart.html#a47a08783a8ec0741a058baf4aa5f761d", null ],
    [ "setVerticalOffsetCh_2", "class_oscilloscope_chart.html#adc1cec6f7247bfba4b269b9d7be2636c", null ],
    [ "timeBase", "class_oscilloscope_chart.html#a71732d3739fdf3875fe70243f22c8fb2", null ],
    [ "updateChart", "class_oscilloscope_chart.html#a1f869e3894a19b41d6d64924d8b63407", null ],
    [ "updateCursorsData", "class_oscilloscope_chart.html#af99d700825b21e169733c7f79a78d31a", null ]
];