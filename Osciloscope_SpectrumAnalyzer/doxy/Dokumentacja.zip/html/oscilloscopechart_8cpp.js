var oscilloscopechart_8cpp =
[
    [ "MICRO_TO_MILLISECONDS", "oscilloscopechart_8cpp.html#a57f9cae8b368b0b34c15ee177d9ae455", null ],
    [ "MICRO_TO_SECONDS", "oscilloscopechart_8cpp.html#a3d476890705f489ae1eae0f81514e79f", null ]
];