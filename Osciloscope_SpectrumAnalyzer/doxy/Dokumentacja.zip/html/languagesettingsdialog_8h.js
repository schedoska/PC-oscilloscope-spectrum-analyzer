var languagesettingsdialog_8h =
[
    [ "LanguageSettingsDialog", "class_language_settings_dialog.html", "class_language_settings_dialog" ]
];