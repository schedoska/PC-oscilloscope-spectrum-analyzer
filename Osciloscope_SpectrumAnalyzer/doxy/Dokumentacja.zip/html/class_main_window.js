var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "changeActive_Ch1", "class_main_window.html#a37c2edda0104e59127e56e5c971c085b", null ],
    [ "changeActive_Ch2", "class_main_window.html#ab8afb5624e3a118bbb60d00388541002", null ],
    [ "setDisabled", "class_main_window.html#a7e902d5a57a14d8c27de49a3c326a27c", null ],
    [ "setEnabled", "class_main_window.html#ac4eaae78ec1d38f40471d6db8a68c75f", null ],
    [ "showLanguageSettingsDialog", "class_main_window.html#af6fbb3456f6d0d292adccf29cb784e9b", null ],
    [ "showPortSettingsDialog", "class_main_window.html#ac7d3116a37d074c7d75b032138510c33", null ],
    [ "updateCursorInfo", "class_main_window.html#acd5d6c2737f325e7148fe8745254a436", null ],
    [ "updateCursorInfoSpectrum", "class_main_window.html#a0d42a86ec5b6542b80dace556caebd5c", null ],
    [ "updateData", "class_main_window.html#a3f356223323116aac25891aefa0b8fdc", null ],
    [ "updateLanguageSettings", "class_main_window.html#a48438ff5bdf8f8565299c898a67f3b41", null ],
    [ "updatePortSettings", "class_main_window.html#a58f114f7329a581500b95a262c57b398", null ]
];