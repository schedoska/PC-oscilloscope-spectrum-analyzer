var signalglobalinformation_8h =
[
    [ "SignalGlobalInformation", "class_signal_global_information.html", "class_signal_global_information" ],
    [ "FREQUENCY_RANKING_SIZE", "signalglobalinformation_8h.html#a428ad27b9d82627dcbc2eab93b2a7ced", null ]
];