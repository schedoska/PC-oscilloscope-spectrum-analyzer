var struct_frequency_sample =
[
    [ "FrequencySample", "struct_frequency_sample.html#a4a8466aaf14058754602dbd27e362efc", null ],
    [ "frequency", "struct_frequency_sample.html#a269d1ae8823055fd836628fd7638eba0", null ],
    [ "value", "struct_frequency_sample.html#a7c5aea9076573097fa35ca87326ba8e2", null ]
];