var oscilloscopechart_8h =
[
    [ "OscilloscopeChart", "class_oscilloscope_chart.html", "class_oscilloscope_chart" ],
    [ "COLOR_RGB_CHANNEL_1", "oscilloscopechart_8h.html#a6eb378cb80819b8dd09dcaaa0bb04883", null ],
    [ "COLOR_RGB_CHANNEL_1_STRING", "oscilloscopechart_8h.html#a658be01175fa40dd6de72f4b59144c5b", null ],
    [ "COLOR_RGB_CHANNEL_2", "oscilloscopechart_8h.html#a615ffcb7776e7266d2b211af5e8f8e73", null ],
    [ "COLOR_RGB_CHANNEL_2_STRING", "oscilloscopechart_8h.html#aa2e2bb36129b8cff4146528a85985830", null ],
    [ "TriggerSlope", "oscilloscopechart_8h.html#a553eb766f03a9a6fd7d7740d89b784e1", [
      [ "RISING", "oscilloscopechart_8h.html#a553eb766f03a9a6fd7d7740d89b784e1ab3762d500f2ada6030da058853c195d6", null ],
      [ "FALLING", "oscilloscopechart_8h.html#a553eb766f03a9a6fd7d7740d89b784e1a4f9d4539ac1e11a251e2afe022eba4e6", null ]
    ] ]
];