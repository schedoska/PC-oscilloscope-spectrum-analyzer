var class_data_communiaction =
[
    [ "DataCommuniaction", "class_data_communiaction.html#a73f838394082615ffd2aee6467d514d8", null ],
    [ "dataReady", "class_data_communiaction.html#a86605b1cb162b6a9ee4ed9ddaa5abac2", null ],
    [ "newDataFrameReady", "class_data_communiaction.html#aad3475bfb0732cf890ff9d1c78283b21", null ],
    [ "setDisabled", "class_data_communiaction.html#ae13fc285f64b13dba4d20935f9ca5a81", null ],
    [ "setEnabled", "class_data_communiaction.html#a74f37bd2386a1dd7a9e573bb610fe309", null ],
    [ "setObservedChannels", "class_data_communiaction.html#aae152e727518760108799f6bb51c5d60", null ],
    [ "setPort", "class_data_communiaction.html#a174bdc1dc42c966e78ffac78dcdf835f", null ],
    [ "setPortConfiguration", "class_data_communiaction.html#adad6e045d9b47455c54bb141c30bc445", null ],
    [ "setTimeBase", "class_data_communiaction.html#af71bcef0905fd17b2236de69626ff6c5", null ],
    [ "setTriggerLevel", "class_data_communiaction.html#ac25e13b3b8eefe1528d7a31ef7f20f18", null ],
    [ "setTriggerSlope", "class_data_communiaction.html#aa570cb9e29dda69a62a5a67e6cf25094", null ],
    [ "setTriggerSource", "class_data_communiaction.html#aa500c06e589b66e3192631f8696adb6e", null ],
    [ "startConnection", "class_data_communiaction.html#a2c951f81d76018e37c67af0a8ebc6bfe", null ],
    [ "stopConnection", "class_data_communiaction.html#a0cb8377591a6a822e2a06a590c1e5f46", null ],
    [ "timeBase", "class_data_communiaction.html#ab3fa43389cf73e74164604ed72a11d65", null ]
];