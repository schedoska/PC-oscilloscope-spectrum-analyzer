var structfftw__iodim64__do__not__use__me =
[
    [ "is", "structfftw__iodim64__do__not__use__me.html#a1b9164674e2d091e8bde88c8d1bb7b6e", null ],
    [ "n", "structfftw__iodim64__do__not__use__me.html#a19f8739d839b44db63c3aa1696a3a038", null ],
    [ "os", "structfftw__iodim64__do__not__use__me.html#a44118d774124bdaa670f640537b151cf", null ]
];