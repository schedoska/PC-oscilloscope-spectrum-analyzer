var struct_relative_raw_sample =
[
    [ "RelativeRawSample", "struct_relative_raw_sample.html#a3fe4b949a7530b1800eb5ffe7a33d4d9", null ],
    [ "convertToSample", "struct_relative_raw_sample.html#ad72e74628dccb102c9305cfca934c07e", null ],
    [ "valueInVolts", "struct_relative_raw_sample.html#acdf300fa76491b661192bac3eb52e29c", null ],
    [ "deltaTime", "struct_relative_raw_sample.html#a1fcb8e381de248aa2f15503f5797d56d", null ],
    [ "value", "struct_relative_raw_sample.html#a4f04c8c9cbb6e215636f19c5c64ea12b", null ]
];