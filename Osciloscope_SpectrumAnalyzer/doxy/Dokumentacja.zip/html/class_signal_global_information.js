var class_signal_global_information =
[
    [ "SignalGlobalInformation", "class_signal_global_information.html#a833f7bf926ce005ddb00da7daefdded5", null ],
    [ "avgValue", "class_signal_global_information.html#ae16c08a5456e48bace543c227c68478c", null ],
    [ "calculateBasicInfo", "class_signal_global_information.html#ad094e8992569530515f8e75d0711407f", null ],
    [ "calculateFFT", "class_signal_global_information.html#a1de4b34189a421ea58f3746f8612377e", null ],
    [ "frequenciesDataList", "class_signal_global_information.html#a12568ce31bcf98b5d398677b73616698", null ],
    [ "frequenciesDataRanking", "class_signal_global_information.html#a7f037faba598fbda61bec1682cd844c0", null ],
    [ "maxValue", "class_signal_global_information.html#a45c5234563e2efa754fbab5889b136a4", null ],
    [ "minValue", "class_signal_global_information.html#acde7ce8b2e9ce1a0f68f367ef731da54", null ],
    [ "peakToPeakValue", "class_signal_global_information.html#a23ed43794563426bb4fe3886afbebf22", null ],
    [ "rmsValue", "class_signal_global_information.html#a28b9ad0e12f35dceb41246b95f58666d", null ],
    [ "setSignalData", "class_signal_global_information.html#a6c29556304077471b8c4625a550cc862", null ]
];